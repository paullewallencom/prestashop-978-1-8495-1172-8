	$(document).ready(function(){
		$('#gallery').galleryView({
			panel_width: 500,
			panel_height: 188,
			frame_width: 100,
			frame_height: 100,
      		transition_speed: 350,
     		easing: 'easeInOutQuad'
		});
	});
