<?php
/*
* block Footer Data
* by Disarci italian community of PrestaShop
* 
* you must configure the data from backoffice
* you can upload an image as logo of the footer
* you have to add to css files:

#ps_menu_text a{
width:138px;  
height:22px; 
float:left;
margin-right:2px;
text-decoration:none;
color: #e8dfd1;
font-family:Verdana, Arial, Helvetica, sans-serif;
	font-size: 9px;
	line-height: 12px;
	font-weight: 100;
	text-align: center;}
#ps_menu_text a:hover{
background-position:center;
}
* as you like
*/

class blockfooterdata extends Module
{
	
	/** @var max image size */
	protected $maxImageSize = 307200;
	function __construct()
	{
		$this->name = 'blockfooterdata';
		$this->tab = 'Blocks';
		$this->version = 1.2;

		parent::__construct(); /* The parent construct is required for translations */

		$this->page = basename(__FILE__, '.php');
		$this->displayName = $this->l('Footer Data block');
		$this->description = $this->l('Adds a block site datas in the footer');
	}

	function install()
	{
		if (!parent::install())
			return false;
		return $this->registerHook('footer');
	}

	function hookFooter($params)
	{
		global $smarty;
		$smarty->assign('ENT_QUOTES', ENT_QUOTES);
		if( file_exists('modules/blockfooterdata/footer_logo.jpg')){
			$smarty->assign('logo','modules/blockfooterdata/footer_logo.jpg');
		};
		$FOOTERdescription=Configuration::get('FOOTER_DESC');
		$smarty->assign('description',$FOOTERdescription );
		return $this->display(__FILE__, 'blockfooterdata.tpl');
	}

	
	function getContent()
	{
		/* display the module name */
		$this->_html = '<h2>'.$this->displayName.'</h2>';

	if (isset($_POST['submitUpdate']))
		{
			if (Tools::isSubmit('submitUpdate') AND ($gai = Tools::getValue('footer_desc')))
			{
				//$gai = htmlentities($gai, ENT_COMPAT, 'UTF-8');
			Configuration::updateValue('FOOTER_DESC', $gai, true);
			$output .= '
			<div class="conf confirm">
				<img src="../img/admin/ok.gif" alt="" title="" />
				'.$this->l('Settings updated').'
			</div>';
			}
			/* delete the image */
			if (Tools::isSubmit('submitUpdate') AND (Tools::getValue('footer_logo_del')=='dele'))
			{
				 unlink (dirname(__FILE__).'/footer_logo.jpg');
					$this->_html .= $this->displayError($this->l('Logo Deleted'));
			}

			/* upload the image */
			if (isset($_FILES['footer_logo']) AND isset($_FILES['footer_logo']['tmp_name']) AND !empty($_FILES['footer_logo']['tmp_name']))
			{
				Configuration::set('PS_IMAGE_GENERATION_METHOD', 1);
				if ($error = checkImage($_FILES['footer_logo'], $this->maxImageSize))
					$this->_html .= $error;
				elseif (!imageResize($_FILES['footer_logo']['tmp_name'], dirname(__FILE__).'/footer_logo.jpg'))
					$this->_html .= $this->displayError($this->l('An error occurred during the image upload.'));
			}
		}

		/* display the editorial's form */
		$this->_displayForm();
		return $this->_html;
	}

	private function _displayForm()
	{
		global $cookie;
				$this->_html .= '<br />
		<form method="post" action="'.$_SERVER['REQUEST_URI'].'" enctype="multipart/form-data">
			<fieldset style="width: 900px;">
				<legend><img src="'.$this->_path.'logo.gif" alt="" title="" /> '.$this->displayName.'</legend>
				<div class="margin-form">
					<textarea name="footer_desc" cols="80" rows="2" />'.Tools::getValue('footer_desc', Configuration::get('FOOTER_DESC')).'</textarea>
			</div>
				<label>'.$this->l('Footer\'s logo').' </label>
				<div class="margin-form">
					<img src="'.$this->_path.'footer_logo.jpg" alt="" title="" style="" /><br />
					<input type="file" name="footer_logo" />
									</div>
					<div class="margin-form">
					<input type="checkbox" name="footer_logo_del" value="dele" >Del Logo?<br>
					</div>
								<div class="clear pspace"></div>
				<div class="margin-form clear"><input type="submit" name="submitUpdate" value="'.$this->l('Update the editor').'" class="button" /></div>
			</fieldset>
		</form>';
	}
}

?>
