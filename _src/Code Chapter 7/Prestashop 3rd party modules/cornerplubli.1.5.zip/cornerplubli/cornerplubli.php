<?php

class Cornerplubli extends Module
{
    private $_html = '';
    private $_postErrors = array();
    private $smallImg;
    private $bigImg;
    private $dirPeel="/peel/";
    private $dirImages="/images/";
    private $fileXml="cornerpubli.xml";
    private $tamImg;

    function __construct()
    {
        $this->name = 'cornerplubli';
        $this->tab = 'Modulos Perrotekel';
        $this->version = '1.5';
        

        parent::__construct();

        /* The parent construct is required for translations */
        $this->page = basename(__FILE__, '.php');
        $this->displayName = $this->l('cornerplubli');
        $this->description = $this->l('Add the Page Peel Effect on the upper of Store');
    }

    function install()
    {

        if (!parent::install())
        return false;
        if (!$this->registerHook('footer'))
        return false;
        return true;
    }



    function hookFooter($param){
        global $smarty;
        $url='';
            $url='http://'.$_SERVER['SERVER_NAME'].__PS_BASE_URI__;



        if (file_exists(dirname(__FILE__).'/'.$this->fileXml))
        if (!$xml = @simplexml_load_file(dirname(__FILE__).'/'.$this->fileXml))
        $this->_html .= $this->displayError($this->l('The file Xml is empty.'));
        $urlDest=($xml ? stripslashes(htmlspecialchars($xml->var_url)) : '');
        $this->smallImg=($xml ? stripslashes(htmlspecialchars($xml->img_small)) : '');
        $this->bigImg=($xml ? stripslashes(htmlspecialchars($xml->img_big)) : '');



        $smarty->assign('dominio', $url);
        $smarty->assign('urlDest', $urlDest);
        $smarty->assign('rutaJs', './modules/'.$this->name.$this->dirPeel);
        $smarty->assign('smallImage', './modules/'.$this->name.$this->dirImages.$this->smallImg);
        $smarty->assign('bigImage', './modules/'.$this->name.$this->dirImages.$this->bigImg);
        return $this->display(__FILE__, 'cornerplubli.tpl');
    }


    public function getContent()
    {
        $output = '<h2>'.$this->displayName.'</h2>';
        if (isset($_POST['submitUpdate']))
        {
            // Generate new XML data
            $newXml = '<?xml version=\'1.0\' encoding=\'utf-8\' ?>'."\n";
            $newXml .= '<cornerpubli>'."\n";
            $newXml .= '	<var_url>'.Tools::getValue('url_detino').'</var_url>'."\n";
            $newXml .= '	<img_small>'.Tools::getValue('file_small').'</img_small>'."\n";
            $newXml .= '	<img_big>'.Tools::getValue('file_big').'</img_big>'."\n";
            $newXml .= "\n".'</cornerpubli>';
            /* write it into the wiznav xml file */
            if ($fd = @fopen(dirname(__FILE__).'/'.$this->fileXml, 'w'))
            {
                if (!@fwrite($fd, $newXml))
                $output .= '<div class="alert error">'.$this->l('Can´t write file '.$this->fileXml);
                if (!@fclose($fd))
                $output .= '<div class="alert error">'.$this->l('Can´t close file '.$this->fileXml);
            }
        }
        if (isset($_POST['submitFile']))
        {
             
            if((!empty($_FILES["uploadFile"])) && ($_FILES['uploadFile']['error'] == 0)) {
                $chkUp=Tools::getValue('chkUpload');
                if($chkUp==1 || $chkUp==2){
             
                    //Check if the file is JPEG image and it's size is less than 350Kb
                    $filename = basename($_FILES['uploadFile']['name']);
                    $ext = substr($filename, strrpos($filename, '.') + 1);
                    if (($ext == "jpg") && ($_FILES["uploadFile"]["type"] == "image/jpeg") &&
                        ($_FILES["uploadFile"]["size"] < 350000)) {
             
                        //Evaluo el tamaño de la imagen
                        $img = ImageCreateFromJpeg($_FILES["uploadFile"]['tmp_name']);
                        $x = ImageSX($img);//para el ancho
                        $y = ImageSY($img);//para el alto
                        $tamano="ok";                        
                        if($chkUp==1 && ($x!=100 || $y!=100)){                            
                            $output .= '<div class="alert error">'.$this->l('The small image must be 100x100');
                            $tamano="error";
                        }
             
                        if($tamano=="ok" && $chkUp==2 && ($x!=500 || $y!=500)){
             
                            $output .= '<div class="alert error">'.$this->l('The big image must be 500x500');
                            $tamano="error";
                        }                            
                        if($tamano=="ok"){
                            //Determine the path to which we want to save this file
                            $newname=dirname(__FILE__).$this->dirImages.$filename;
                            //Check if the file with the same name is already exists on the server
                            if (!file_exists($newname)) {
                                //Attempt to move the uploaded file to it's new place
                                if ((move_uploaded_file($_FILES['uploadFile']['tmp_name'],$newname))) {
                                    $output .= '<div class="alert error">'.$this->l('The file have saved : '.$newname);
                                } else {
                                    $output .= '<div class="alert error">'.$this->l('Error: An error occurred uploading the file!');
                                }
                            } else {
                                $output .= '<div class="alert error">'.$this->l('Error: The file exist :').$_FILES["uploadFile"]["name"];
                            }
                        }
                    } else {                        
                        $output .= '<div class="alert error">'.$this->l('Error: You can only upload jpg files for this module').'</div>';
                    }
                }else{
                    $output .= '<div class="alert error">'.$this->l('You must select big image or small image');
                }
            } else {
                $output .= '<div class="alert error">'.$this->l('Error: File have not upload');
            }
        }


        /* display the CORNERPUBLI form */
        return $output.$this->displayForm();
    }


    public function displayForm()
    {
        global $cookie;

        /* xml loading */
        $xml = false;
        if (file_exists(dirname(__FILE__).'/'.$this->fileXml))
        if (!$xml = @simplexml_load_file(dirname(__FILE__).'/'.$this->fileXml))
        $this->_html .= $this->displayError($this->l('The file not exist: ').$this->fileXml);


        //Leo la imagen pequeña y la grande

        $this->smallImg=($xml ? stripslashes(htmlspecialchars($xml->img_small)) : '');
        $this->bigImg=($xml ? stripslashes(htmlspecialchars($xml->img_big)) : '');

        $this->_html .= '<br />


        <form method="post" action="'.$_SERVER['REQUEST_URI'].'" enctype="multipart/form-data">
            <fieldset style="width: 900px;">
                <legend><img src="'.$this->_path.'logo.gif" alt="" title="" /> '.$this->displayName.'</legend>

                <label>'.$this->l('Configuration').'</label><p>&nbsp;<p/>
                <label>'.$this->l('Destination Url').'</label>
                <div class="margin-form">
                    <input type="text" name="url_detino" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->var_url)) : '').'" />
                </div>
                <label>&nbsp;</label>
                <div class="margin-form">
                <label style="float:none;width:280px" >'.$this->l('Example').': http://www.supersoundone.com</label>
                </div>
                <label>'.$this->l('Small File').'</label>
                <div class="margin-form">
                    <select name="file_small" size="1" id="file_small" ">';
        $this->_html.='<OPTION VALUE=""></OPTION> ';
        $directorio=opendir(dirname(__FILE__).$this->dirImages);
        while ($archivo = readdir($directorio)){
            if(substr($archivo, strrpos($archivo, '.') + 1) == "jpg")
            {
                if($archivo==$this->smallImg){
                    $this->_html.='<OPTION VALUE="'.$archivo.'" SELECTED >'.$archivo.'</OPTION> ';
                }else{
                    $this->_html.='<OPTION VALUE="'.$archivo.'">'.$archivo.'</OPTION> ';
                }
            }
        }

        $this->_html .= '</select>&nbsp;&nbsp;'.$this->l('The image  must be 100x100 and jpg').'
                </div>
                <label>'.$this->l('Big File').'</label>
                <div class="margin-form">
                    <select name="file_big" size="1" id="file_big" ">';
        $this->_html.='<OPTION VALUE=""></OPTION> ';
        $directorio=opendir(dirname(__FILE__).$this->dirImages);
        while ($archivo = readdir($directorio)){            

            if(substr($archivo, strrpos($archivo, '.') + 1) == "jpg")
            {

                if($archivo==$this->bigImg){
                    $this->_html.='<OPTION VALUE="'.$archivo.'" SELECTED >'.$archivo.'</OPTION> ';
                }else{
                    $this->_html.='<OPTION VALUE="'.$archivo.'">'.$archivo.'</OPTION> ';
                }
            }
        }



        closedir($directorio);

        $this->_html .= '</select>&nbsp;&nbsp;'.$this->l('The image  must be 500x500 and jpg').'
                </div>
                </br>
                <label>'.$this->l('Upload File').'</label>
                <div class="margin-form">
                    <input type="radio" name="chkUpload" checked="true" value="1"/>'.$this->l('Small Image').'
                    <input type="radio" name="chkUpload"  value="2"/>'.$this->l('Big Image').'
                    <input type="file" name="uploadFile" />
                    <input type="submit" name="submitFile" value="'.$this->l('Upload File').'" class="button" />
                </div>

                <div class="clear pspace"></div>
                <div class="margin-form clear">
                    <input type="submit" name="submitUpdate" value="'.$this->l('Save').'" class="button" />
                </div>
            </fieldset>
        </form>';
        return $this->_html;
    }



}


?>
