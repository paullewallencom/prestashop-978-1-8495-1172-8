<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cornerplubli}prestashop>cornerplubli_7e9cdb9b808bae2fbb5043a495b6ac84'] = 'cornerplubli';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_e776c8385f7cb30ae0eceecb13d65f73'] = 'Add the Page Peel Effect on the upper of Store';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_84d0b43835b5f0501a2bff950ab07402'] = 'The file Xml is empty.';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_558a80f37aaecd713b92cdfcdf61b9a2'] = 'The small image must be 100x100';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_3e2c6e7973f99460d08ce50d15c27c2d'] = 'The big image must be 500x500';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_721f70cf01bdeed784471a393ac020e4'] = 'Error: An error occurred uploading the file!';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_cdfb437e70b28bb218b439687f868de9'] = 'Error: The file exist :';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_986da4af7d47a52b616e4af4d7f12a83'] = 'Error: You can only upload jpg files for this module';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_24711f69b321147a48732be151dcfd6c'] = 'You must select big image or small image';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_ca03d0bd2e4b04e848014106392da011'] = 'Error: File have not upload';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_f3d098fe3021cd03a1ab835f10d94269'] = 'The file not exist: ';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_2397770295600fa303b9e5b52a1d4b1d'] = 'Destination Url';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_0a52730597fb4ffa01fc117d9e71e3a9'] = 'Example';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_b97e618179197fe0aee32578dc98fe64'] = 'Small File';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_992fab556b47064531d2a75be70aac7e'] = 'The image must be 100x100 and jpg';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_479a5cb4d3f9ec1f0bc6fce376276a25'] = 'Big File';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_82be3a94cab030c789f8db918e9ea079'] = 'The image must be 500x500 and jpg';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_fbb7d71920afdff488c3514f3f99fe7c'] = 'Upload File';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_324ec8795c86285945b0d18330b67baf'] = 'Small Image';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_49ddf04170f3f2440931bedd7ba22b3b'] = 'Big Image';
$_MODULE['<{cornerplubli}prestashop>cornerplubli_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
