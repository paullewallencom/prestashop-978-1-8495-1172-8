<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{wiznav}prestashop>wiznav_824b8e5509ca4517e3f5d0e421576709'] = 'Wiznav';
$_MODULE['<{wiznav}prestashop>wiznav_727224204b048c2724aeb6f63e590332'] = 'Wiznav est une barre de navigation addon';
$_MODULE['<{wiznav}prestashop>wiznav_2bec5db43b6d1f9fd801c33c401c15a5'] = 'Êtes-vous sûr de vouloir unistall Wiznav?';
$_MODULE['<{wiznav}prestashop>wiznav_5be920293db3e38c81330fd0798336b1'] = 'Html champ non valide, javascript est interdit';
$_MODULE['<{wiznav}prestashop>wiznav_14578e1c6d4456fbe7cb6fadb4215eac'] = 'Impossible d\'écrire dans le fichier Wiznav.';
$_MODULE['<{wiznav}prestashop>wiznav_0db94a70f84a64498d07f3f1e54a8696'] = 'Impossible de fermer le fichier Wiznav.';
$_MODULE['<{wiznav}prestashop>wiznav_af65b6a2993524b722d05a617bc36793'] = 'Impossible de mettre à jour le fichier Wiznav.rnS\'il vous plaît vérifier les permissions d\'ecriture du fichier Wiznav .';
$_MODULE['<{wiznav}prestashop>wiznav_eec34a41e732e39809721bab40e601cd'] = 'Votre éditeur de fichier est vide.';
$_MODULE['<{wiznav}prestashop>wiznav_327238bd6e361ff553e05b5ae13ca898'] = 'Onglet 1';
$_MODULE['<{wiznav}prestashop>wiznav_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{wiznav}prestashop>wiznav_43d77a8036a399e61f8358b38fd9122b'] = 'Onglet 2';
$_MODULE['<{wiznav}prestashop>wiznav_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{wiznav}prestashop>wiznav_5153a5aacd32b6b436357b52db073d18'] = 'Onglet 3';
$_MODULE['<{wiznav}prestashop>wiznav_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{wiznav}prestashop>wiznav_d124771db567901418807097c53bf09b'] = 'Onglet 4';
$_MODULE['<{wiznav}prestashop>wiznav_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{wiznav}prestashop>wiznav_ee67339583b30d0e9f18d5517e21adbf'] = 'Onglet 5';
$_MODULE['<{wiznav}prestashop>wiznav_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{wiznav}prestashop>wiznav_2b69b52ca29441f06dcf08131c1766bc'] = 'Onglet 6';
$_MODULE['<{wiznav}prestashop>wiznav_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{wiznav}prestashop>wiznav_af11cc3d5b510410b5a343536cc21461'] = 'Onglet 7';
$_MODULE['<{wiznav}prestashop>wiznav_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{wiznav}prestashop>wiznav_5bad7a44944a7eb5b3bebc656412bb1d'] = 'Onglet 8';
$_MODULE['<{wiznav}prestashop>wiznav_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{wiznav}prestashop>wiznav_a8bd45128f926ffc438eb5a2851c9a9e'] = 'Onglet 9';
$_MODULE['<{wiznav}prestashop>wiznav_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{wiznav}prestashop>wiznav_5dbaa59136b85a436e01dc633dd0d2ee'] = 'Onglet 10';
$_MODULE['<{wiznav}prestashop>wiznav_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{wiznav}prestashop>wiznav_824b8e5509ca4517e3f5d0e421576709'] = 'Wiznav';
$_MODULE['<{wiznav}prestashop>wiznav_b555fcf449d57e2102a3f5e7c4192f8a'] = 'Wiznav personalizado';
$_MODULE['<{wiznav}prestashop>wiznav_3adbdb3ac060038aa0e6e6c138ef9873'] = 'Catégorie';
$_MODULE['<{wiznav}prestashop>wiznav_8cc149b77eaece54cee2e7e02f40018a'] = 'Barre de recherche';
$_MODULE['<{wiznav}prestashop>wiznav_f5cf47ab06d0d98b0d16d10c82d87953'] = 'GARDER';
$_MODULE['<{wiznav}prestashop>wiznav_8cf04a9734132302f96da8e113e80ce5'] = 'Accueil';
$_MODULE['<{wiznav}prestashop>wiznav_af1b98adf7f686b84cd0b443e022b7a0'] = 'Catégories';
$_MODULE['<{wiznav}prestashop>wiznav_9e66e6bd4069124578736528a0432752'] = 'Qui sommes?';
$_MODULE['<{wiznav}prestashop>wiznav_5813ce0ec7196c492c97596718f71969'] = 'Site';
$_MODULE['<{wiznav}prestashop>wiznav_9cfc9b74983d504ec71db33967591249'] = 'Contactez';
$_MODULE['<{wiznav}prestashop>wiznav_38afb4cd458f868284f38c901da91dae'] = 'Favoris';
$_MODULE['<{wiznav}prestashop>wiznav_0323de4f66a1700e2173e9bcdce02715'] = 'Déconnexion';
$_MODULE['<{wiznav}prestashop>wiznav_99dea78007133396a7b8ed70578ac6ae'] = 'Identifiez-vous';
$_MODULE['<{wiznav}prestashop>wiznav_af1b98adf7f686b84cd0b443e022b7a0'] = 'Catégories';

?>
