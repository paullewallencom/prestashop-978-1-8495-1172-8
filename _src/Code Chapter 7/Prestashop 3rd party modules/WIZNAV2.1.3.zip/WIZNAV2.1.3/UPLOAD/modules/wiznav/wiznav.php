<?php
/**================================================================

PrestaShop-Theme_Module
Wiznav 2.1.3 by Hieloiceberg
http://www.prestashop.com/forums/member/15185/hieloiceberg/
French and Spanish Translation By junnecito
http://www.prestashop.com/forums/member/1132/junnecito/
Prestashop Version 1.2.0.1

===================================================================*/

class Wiznav extends Module
{

	function __construct()
	{
		$this->name = 'wiznav';
		$this->tab = 'Wizard Workz';
		$this->version = '2.0.1';
		
		parent::__construct();
		
		$this->displayName = $this->l('Wiznav');
		$this->description = $this->l('Wiznav is a navigation bar addon');
		$this->confirmUninstall = $this->l('Are you sure you want to unistall Wiznav?');
	}

	function install()
	{
		if (!parent::install()
		OR !$this->installDB() 
		OR !$this->registerHook('wiznav'))
			return false;
		return true;
	}
	
	function installDB()
	{
		Db::getInstance()->Execute('
		INSERT INTO `'._DB_PREFIX_.'hook` (`name`, `title`) 
		VALUES (\'wiznav\', \'Wiznav Hook\')');				
		return true;
	}

	function uninstall()
	{
		if (!parent::uninstall()
				OR !$this->uninstallDB()
			)
			return false;
		return true;
	}


	function uninstallDB()
	{
		Db::getInstance()->Execute('
		DELETE FROM `'._DB_PREFIX_.'hook` 
		WHERE `name` = \'wiznav\'');			
		return true;
	}	



	function putContent($xml_data, $key, $field, $forbidden, $section)
	{
		foreach ($forbidden AS $line)
			if ($key == $line)
				return 0;
		if (!eregi('^'.$section.'_', $key))
			return 0;
		$key = eregi_replace('^'.$section.'_', '', $key);
		//$field = pSQL($field);
		$field = htmlspecialchars($field);
		if (!$field)
			return 0;
		return ("\n".'		<'.$key.'>'.$field.'</'.$key.'>');
	}

	function getContent()
	{
		/* display the module name */
		$this->_html = '<h2>'.$this->displayName.'</h2>';

		/* update the wiznav xml */
		if (isset($_POST['submitUpdate']))
		{
		
			$wiznavbar = intval(Tools::getValue('wiznavbar'));
			Configuration::updateValue('DISPLAY_WIZNAVBAR', $wiznavbar);
			$wiznavsearch = intval(Tools::getValue('wiznavsearch'));
			Configuration::updateValue('DISPLAY_WIZSEARCH', $wiznavsearch);	
			$wizcat = intval(Tools::getValue('wizcat'));
			Configuration::updateValue('DISPLAY_WIZCAT', $wizcat);			
		
			// Forbidden key
			$forbidden = array('submitUpdate');
			
			foreach ($_POST AS $key => $value)
				if (!Validate::isCleanHtml($_POST[$key]))
				{
					$this->_html .= $this->displayError($this->l('Invalid html field, javascript is forbidden'));
					$this->_displayForm();
					return $this->_html;
				}

			// Generate new XML data
			$newXml = '<?xml version=\'1.0\' encoding=\'utf-8\' ?>'."\n";
			$newXml .= '<wiznav>'."\n";
			$newXml .= '	<header>';
			// Making header data
			foreach ($_POST AS $key => $field)
				if ($line = $this->putContent($newXml, $key, $field, $forbidden, 'header'))
					$newXml .= $line;
			$newXml .= "\n".'	</header>'."\n";
			$newXml .= '	<body>';
			// Making body data
			foreach ($_POST AS $key => $field)
				if ($line = $this->putContent($newXml, $key, $field, $forbidden, 'body'))
					$newXml .= $line;
			$newXml .= "\n".'	</body>'."\n";
			$newXml .= '</wiznav>'."\n";

			/* write it into the wiznav xml file */
			if ($fd = @fopen(dirname(__FILE__).'/wiznav.xml', 'w'))
			{
				if (!@fwrite($fd, $newXml))
					$this->_html .= $this->displayError($this->l('Unable to write to the Wiznav file.'));
				if (!@fclose($fd))
					$this->_html .= $this->displayError($this->l('Can\'t close the Wiznav file.'));
			}
			else
				$this->_html .= $this->displayError($this->l('Unable to update the Wiznav file.<br />Please check the Wiznav file\'s writing permissions.'));
		}

		/* display the wiznav's form */
		$this->_displayForm();
	
		return $this->_html;
	}

	private function _displayForm()
	{
		global $cookie;
		
		/* Languages preliminaries */
		$defaultLanguage = intval(Configuration::get('PS_LANG_DEFAULT'));
		$languages = Language::getLanguages();
		$iso = Language::getIsoById($defaultLanguage);
		$divLangName = 'tab1¤tab2¤tab3¤tab4¤tab5¤tab6¤tab7¤tab8¤tab9¤tab10';

		/* xml loading */
		$xml = false;
		if (file_exists(dirname(__FILE__).'/wiznav.xml'))
				if (!$xml = @simplexml_load_file(dirname(__FILE__).'/wiznav.xml'))
					$this->_html .= $this->displayError($this->l('Your editor file is empty.'));

		$this->_html .= '<br />

		<script language="javascript">id_language = Number('.$defaultLanguage.');</script>
		<form method="post" action="'.$_SERVER['REQUEST_URI'].'" enctype="multipart/form-data">
			<fieldset style="width: 900px;">
				<legend><img src="'.$this->_path.'logo.gif" alt="" title="" /> '.$this->displayName.'</legend>




				<label>'.$this->l('Tab 1').'</label>
				<div class="margin-form">';				
				foreach ($languages as $language)
				{
					$this->_html .= '
					<div id="tab1_'.$language['id_lang'].'" style="display: '.($language['id_lang'] == $defaultLanguage ? 'block' : 'none').';float: left;">
						<input type="text" name="body_tab1_'.$language['id_lang'].'" id="body_tab1_'.$language['id_lang'].'" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->{'tab1_'.$language['id_lang']})) : '').'" />
					</div>';
				 }
				$this->_html .= $this->displayFlags($languages, $defaultLanguage, $divLangName, 'tab1', true);				
		$this->_html .= '
				</div></br>
				<label>'.$this->l('Link').'</label>
				<div class="margin-form">
					<input type="text" name="body_tab1_link" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->tab1_link)) : '').'" />
				</div>
				
				
				
				<label>'.$this->l('Tab 2').'</label>
				<div class="margin-form">';				
				foreach ($languages as $language)
				{
					$this->_html .= '
					<div id="tab2_'.$language['id_lang'].'" style="display: '.($language['id_lang'] == $defaultLanguage ? 'block' : 'none').';float: left;">
						<input type="text" name="body_tab2_'.$language['id_lang'].'" id="body_tab2_'.$language['id_lang'].'" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->{'tab2_'.$language['id_lang']})) : '').'" />
					</div>';
				 }
				$this->_html .= $this->displayFlags($languages, $defaultLanguage, $divLangName, 'tab2', true);				
		$this->_html .= '
				</div></br>
				<label>'.$this->l('Link').'</label>
				<div class="margin-form">
					<input type="text" name="body_tab2_link" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->tab2_link)) : '').'" />
				</div>	
							


				<label>'.$this->l('Tab 3').'</label>
				<div class="margin-form">';				
				foreach ($languages as $language)
				{
					$this->_html .= '
					<div id="tab3_'.$language['id_lang'].'" style="display: '.($language['id_lang'] == $defaultLanguage ? 'block' : 'none').';float: left;">
						<input type="text" name="body_tab3_'.$language['id_lang'].'" id="body_tab3_'.$language['id_lang'].'" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->{'tab3_'.$language['id_lang']})) : '').'" />
					</div>';
				 }
				$this->_html .= $this->displayFlags($languages, $defaultLanguage, $divLangName, 'tab3', true);				
		$this->_html .= '
				</div></br>
				<label>'.$this->l('Link').'</label>
				<div class="margin-form">
					<input type="text" name="body_tab3_link" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->tab3_link)) : '').'" />
				</div>



				<label>'.$this->l('Tab 4').'</label>
				<div class="margin-form">';				
				foreach ($languages as $language)
				{
					$this->_html .= '
					<div id="tab4_'.$language['id_lang'].'" style="display: '.($language['id_lang'] == $defaultLanguage ? 'block' : 'none').';float: left;">
						<input type="text" name="body_tab4_'.$language['id_lang'].'" id="body_tab4_'.$language['id_lang'].'" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->{'tab4_'.$language['id_lang']})) : '').'" />
					</div>';
				 }
				$this->_html .= $this->displayFlags($languages, $defaultLanguage, $divLangName, 'tab4', true);				
		$this->_html .= '
				</div></br>
				<label>'.$this->l('Link').'</label>
				<div class="margin-form">
					<input type="text" name="body_tab4_link" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->tab4_link)) : '').'" />
				</div>



				<label>'.$this->l('Tab 5').'</label>
				<div class="margin-form">';				
				foreach ($languages as $language)
				{
					$this->_html .= '
					<div id="tab5_'.$language['id_lang'].'" style="display: '.($language['id_lang'] == $defaultLanguage ? 'block' : 'none').';float: left;">
						<input type="text" name="body_tab5_'.$language['id_lang'].'" id="body_tab5_'.$language['id_lang'].'" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->{'tab5_'.$language['id_lang']})) : '').'" />
					</div>';
				 }
				$this->_html .= $this->displayFlags($languages, $defaultLanguage, $divLangName, 'tab5', true);				
		$this->_html .= '
				</div></br>
				<label>'.$this->l('Link').'</label>
				<div class="margin-form">
					<input type="text" name="body_tab5_link" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->tab5_link)) : '').'" />
				</div>
				
				
				
				<label>'.$this->l('Tab 6').'</label>
				<div class="margin-form">';				
				foreach ($languages as $language)
				{
					$this->_html .= '
					<div id="tab6_'.$language['id_lang'].'" style="display: '.($language['id_lang'] == $defaultLanguage ? 'block' : 'none').';float: left;">
						<input type="text" name="body_tab6_'.$language['id_lang'].'" id="body_tab6_'.$language['id_lang'].'" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->{'tab6_'.$language['id_lang']})) : '').'" />
					</div>';
				 }
				$this->_html .= $this->displayFlags($languages, $defaultLanguage, $divLangName, 'tab6', true);				
		$this->_html .= '
				</div></br>
				<label>'.$this->l('Link').'</label>
				<div class="margin-form">
					<input type="text" name="body_tab6_link" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->tab6_link)) : '').'" />
				</div>
				
				
				
				
				<label>'.$this->l('Tab 7').'</label>
				<div class="margin-form">';				
				foreach ($languages as $language)
				{
					$this->_html .= '
					<div id="tab7_'.$language['id_lang'].'" style="display: '.($language['id_lang'] == $defaultLanguage ? 'block' : 'none').';float: left;">
						<input type="text" name="body_tab7_'.$language['id_lang'].'" id="body_tab7_'.$language['id_lang'].'" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->{'tab7_'.$language['id_lang']})) : '').'" />
					</div>';
				 }
				$this->_html .= $this->displayFlags($languages, $defaultLanguage, $divLangName, 'tab7', true);				
		$this->_html .= '
				</div></br>
				<label>'.$this->l('Link').'</label>
				<div class="margin-form">
					<input type="text" name="body_tab7_link" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->tab7_link)) : '').'" />
				</div>
				
				
				
				<label>'.$this->l('Tab 8').'</label>
				<div class="margin-form">';				
				foreach ($languages as $language)
				{
					$this->_html .= '
					<div id="tab8_'.$language['id_lang'].'" style="display: '.($language['id_lang'] == $defaultLanguage ? 'block' : 'none').';float: left;">
						<input type="text" name="body_tab8_'.$language['id_lang'].'" id="body_tab8_'.$language['id_lang'].'" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->{'tab8_'.$language['id_lang']})) : '').'" />
					</div>';
				 }
				$this->_html .= $this->displayFlags($languages, $defaultLanguage, $divLangName, 'tab8', true);				
		$this->_html .= '
				</div></br>
				<label>'.$this->l('Link').'</label>
				<div class="margin-form">
					<input type="text" name="body_tab8_link" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->tab8_link)) : '').'" />
				</div>
				
				
				
				<label>'.$this->l('Tab 9').'</label>
				<div class="margin-form">';				
				foreach ($languages as $language)
				{
					$this->_html .= '
					<div id="tab9_'.$language['id_lang'].'" style="display: '.($language['id_lang'] == $defaultLanguage ? 'block' : 'none').';float: left;">
						<input type="text" name="body_tab9_'.$language['id_lang'].'" id="body_tab9_'.$language['id_lang'].'" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->{'tab9_'.$language['id_lang']})) : '').'" />
					</div>';
				 }
				$this->_html .= $this->displayFlags($languages, $defaultLanguage, $divLangName, 'tab9', true);				
		$this->_html .= '
				</div></br>
				<label>'.$this->l('Link').'</label>
				<div class="margin-form">
					<input type="text" name="body_tab9_link" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->tab9_link)) : '').'" />
				</div>
				
				
				
				<label>'.$this->l('Tab 10').'</label>
				<div class="margin-form">';				
				foreach ($languages as $language)
				{
					$this->_html .= '
					<div id="tab10_'.$language['id_lang'].'" style="display: '.($language['id_lang'] == $defaultLanguage ? 'block' : 'none').';float: left;">
						<input type="text" name="body_tab10_'.$language['id_lang'].'" id="body_tab10_'.$language['id_lang'].'" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->{'tab10_'.$language['id_lang']})) : '').'" />
					</div>';
				 }
				$this->_html .= $this->displayFlags($languages, $defaultLanguage, $divLangName, 'tab10', true);				
		$this->_html .= '
				</div></br>
				<label>'.$this->l('Link').'</label>
				<div class="margin-form">
					<input type="text" name="body_tab10_link" size="64" value="'.($xml ? stripslashes(htmlspecialchars($xml->body->tab10_link)) : '').'" />
				</div>																				




				<label>'.$this->l('Wiznav').'</label>
				<div class="margin-form">
					<input type="radio" name="wiznavbar" id="wiznavbar_on" value="1" '.(Tools::getValue('wiznavbar', Configuration::get('DISPLAY_WIZNAVBAR')) ? 'checked="checked" ' : '').'/>
					<label class="t" for="wiznavbar_on"> <img src="../img/admin/enabled.gif" /></label>					
				</div>						
				<label>'.$this->l('Wiznav Costume').'</label>
				<div class="margin-form">
					<input type="radio" name="wiznavbar" id="wiznavbar_off" value="0" '.(!Tools::getValue('wiznavbar', Configuration::get('DISPLAY_WIZNAVBAR')) ? 'checked="checked" ' : '').'/>									
					<label class="t" for="wiznavbar_off"> <img src="../img/admin/enabled.gif" /></label>
				</div>
				

				<label>'.$this->l('Category').'</label>
				<div class="margin-form">
					<input type="radio" name="wizcat" id="text_list_on" value="1" '.(Tools::getValue('text_list', Configuration::get('DISPLAY_WIZCAT')) ? 'checked="checked" ' : '').'/>
					<label class="t" for="text_list_on"> <img src="../img/admin/enabled.gif" /></label>
					<input type="radio" name="wizcat" id="text_list_off" value="0" '.(!Tools::getValue('text_list', Configuration::get('DISPLAY_WIZCAT')) ? 'checked="checked" ' : '').'/>
					<label class="t" for="text_list_off"> <img src="../img/admin/disabled.gif" /></label>
				</div>	

				
				<label>'.$this->l('Search Bar').'</label>
				<div class="margin-form">
					<input type="radio" name="wiznavsearch" id="text_list_on" value="1" '.(Tools::getValue('text_list', Configuration::get('DISPLAY_WIZSEARCH')) ? 'checked="checked" ' : '').'/>
					<label class="t" for="text_list_on"> <img src="../img/admin/enabled.gif" /></label>
					<input type="radio" name="wiznavsearch" id="text_list_off" value="0" '.(!Tools::getValue('text_list', Configuration::get('DISPLAY_WIZSEARCH')) ? 'checked="checked" ' : '').'/>
					<label class="t" for="text_list_off"> <img src="../img/admin/disabled.gif" /></label>
				</div>				


				<div class="clear pspace"></div>
				<div class="margin-form clear"><input type="submit" name="submitUpdate" value="'.$this->l('SAVE').'" class="button" /></div>
			</fieldset>
		</form>';
	}

	function hookWiznav($params)
	{
		if (file_exists('modules/wiznav/wiznav.xml'))
		{
			if ($xml = simplexml_load_file('modules/wiznav/wiznav.xml'))
			{
				global $cookie, $smarty;
				$smarty->assign(array(
					'xml' => $xml,
					'tab1' => 'tab1_'.$cookie->id_lang,
					'tab2' => 'tab2_'.$cookie->id_lang,
					'tab3' => 'tab3_'.$cookie->id_lang,
					'tab4' => 'tab4_'.$cookie->id_lang,
					'tab5' => 'tab5_'.$cookie->id_lang,
					'tab6' => 'tab6_'.$cookie->id_lang,
					'tab7' => 'tab7_'.$cookie->id_lang,
					'tab8' => 'tab8_'.$cookie->id_lang,
					'tab9' => 'tab9_'.$cookie->id_lang,
					'tab10' => 'tab10_'.$cookie->id_lang,
					'wiznavbar' => Configuration::get('DISPLAY_WIZNAVBAR'),
					'wiznavsearch' => Configuration::get('DISPLAY_WIZSEARCH'),
					'wizcat' => Configuration::get('DISPLAY_WIZCAT'),
					'this_path' => $this->_path
				));
				return $this->display(__FILE__, 'wiznav.tpl');
			}
		}
		return false;
	}		
}
