<?php
/*
	Module Name: Moving Boxes
	Module URI: http://www.ecartservice.net/products-page/
	Description: Yet another jQuery featured products module
	Version: 0.1.0
	Author: Paul Campbell
	Author URI: http://www.ecartservice.net/
	
	Copyright 2009, paul r campbell (pcampbell@ecartservice.net)

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.	
*/

class MovingBoxes extends Module
{
	private $_html = '';
	private $_postErrors = array();
	
	function __construct()
	{
		$this->name = 'movingboxes';		
		parent::__construct();
				
		$this->tab = 'eCartService.net';
		$this->version = '0.1.1';
		$this->displayName = $this->l('Moving Boxes - Home page featured products');
		$this->description = $this->l('A simple jQuery scrollable featured products module.');			
	}

	public function install()
	{
		parent::install();
		
		if (!$this->registerHook('home'))
			return false;
		
		if (!$this->registerHook('header'))
			return false;
			
		// Set defaults
		Configuration::updateValue($this->name.'_number', 10);
	}
	
	public function uninstall()
	{	
		Configuration::deleteByName($this->name.'_number');
		parent::uninstall();
	}

	private function _postValidation()
	{
		if (!Validate::isUnsignedInt(Tools::getValue('number')))
			$this->_postErrors[] = $this->l('Number of products must be a postive integer');
	}
	
	private function _postProcess()
	{
		Configuration::updateValue($this->name.'_number', Tools::getValue('number'));
		
		$this->_html .= '<div class="conf confirm">'.$this->l('Settings updated').'</div>';
	}
	
	public function getContent()
	{
		$this->_html .= '<h2>'.$this->displayName.'</h2>';
		
		if (Tools::isSubmit('submit'))
		{			
			$this->_postValidation();
			
			if (!sizeof($this->_postErrors))
				$this->_postProcess();
			else
			{
				foreach ($this->_postErrors AS $err)
				{
					$this->_html .= '<div class="alert error">'.$err.'</div>';
				}
			}
		}
		
		$this->_displayForm();
		
		return $this->_html;
	}
	
	private function _displayForm()
	{
		$this->_html .= '
		<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
			<fieldset>
				<legend><img src="../img/admin/cog.gif" alt="" class="middle" />'.$this->l('Settings').'</legend>
				<label>'.$this->l('Max. to display:').'</label>
				<div class="margin-form">
					<input type="text" name="number" value="'.Tools::getValue('number', Configuration::get($this->name.'_number')).'"/>
					<p class="clear">'.$this->l('The number of products to show in the homepage slider').'</p>
				</div>
			<input type="submit" name="submit" value="'.$this->l('Update').'" class="button" />
			</fieldset>			
		</form>';	
	}
		
	public function hookHome($params)
	{
		global $smarty;
		
		$category = new Category(1);
		$nb = intval(Configuration::get($this->name.'_number'));
		$products = $category->getProducts(intval($params['cookie']->id_lang), 1, ($nb ? $nb : 10), 'date_add', 'DESC');
		$smarty->assign(array(
			$this->name.'_products' => $products,
			$this->name.'_path' => _MODULE_DIR_.$this->name.'/',
			$this->name.'_offer_message' => $this->l('Only')
		));
		return $this->display(__FILE__, 'movingboxes.tpl');
	}
		
	public function hookHeader($params)
	{
		$head_content='<link media="all" type="text/css" rel="stylesheet" href="'._MODULE_DIR_.$this->name.'/css/style.css"/>';
		$head_content.='<script type="text/javascript" src="'._MODULE_DIR_.$this->name.'/js/slider.js"></script>';
		return $head_content;
	}
	
}
// End of: movingboxes.php
