<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_2c35feb6fb66b979904e8df5e004cc44'] = 'Bloc catégories en haut de page';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_42b4df2ae162cd1a90b5cc0b3b3a9564'] = 'Ajoute un bloc en haut de page proposant une navigation au sein de vos catégories de produits';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Profondeur maximum : nombre invalide';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_d27918bf3a9eeb40cf725179b38bf6af'] = 'Largeur des onglets : choix invalide';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_77625ac78b6ca4366e77921e9d17c489'] = 'Délai : nombre invalide';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmation';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_19561e33450d1d3dfe6af08df5710dd0'] = 'Profondeur maximum';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_ef35cd8f1058f29151991e9ca94b36fb'] = 'Détermine la profondeur maximale affichée (0 = infinie)';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_fbc43874cdf5d9af3f3822929998880e'] = 'Largeur des onglets';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_960b44c579bc2f6818d2daaf9e4c16f0'] = 'Normal';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_30bb747c98bccdd11b3f89e644c4d0ad'] = 'Court';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_110ab3005329b7c7063e05fa31f37f52'] = 'Détermine la largeur des onglets';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_8f497c1a3d15af9e0c215019f26b887d'] = 'Délai';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_1caafaa4cf81fac0c9f1ac776cf23025'] = 'Détermine le délai de l\'animation (0 = pas d\'animation)';
$_MODULE['<{blockcategoriestopsc}prestashop>blockcategoriestopsc_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
