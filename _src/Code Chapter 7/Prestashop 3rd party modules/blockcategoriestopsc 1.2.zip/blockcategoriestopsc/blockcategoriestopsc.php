<?php

class BlockCategoriesTopSc extends Module
{
	function __construct()
	{
		$this->name = 'blockcategoriestopsc';
		$this->tab = 'par Cegiel modifie par Maxhome';
		$this->version = 1.2;

		parent::__construct();

		$this->displayName = $this->l('Categories block on the top');
		$this->description = $this->l('Adds a top block featuring product categories on the top using tabs');
	}

	function install()
	{
		if (parent::install() == false
			OR $this->registerHook('top') == false
			OR Configuration::updateValue('BLOCK_CATEG_MAX_DEPTH', 3) == false
			OR Configuration::updateValue('BLOCK_CATEG_TOPSC_DELAY', 250) == false)
			return false;
		return true;
	}

	public function getContent()
	{
		$output = '<h2>'.$this->displayName.'</h2>';
		if (Tools::isSubmit('submitBlockCategoriesTopSc'))
		{
			$maxDepth = intval(Tools::getValue('maxDepth'));
			$delay = intval(Tools::getValue('delay'));
			if ($maxDepth < 0)
				$output .= '<div class="alert error">'.$this->l('Maximum depth: Invalid number.').'</div>';
			elseif ($delay < 0)
				$output .= '<div class="alert error">'.$this->l('Delay: Invalid number.').'</div>';
			else
			{
				Configuration::updateValue('BLOCK_CATEG_MAX_DEPTH', intval($maxDepth));
				Configuration::updateValue('BLOCK_CATEG_TOPSC_DELAY', intval($delay));
				$output .= '<div class="conf confirm"><img src="../img/admin/ok.gif" alt="'.$this->l('Confirmation').'" />'.$this->l('Settings updated').'</div>';
			}
		}
		return $output.$this->displayForm();
	}

	public function displayForm()
	{
		return '
		<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
			<fieldset>
				<legend><img src="'.$this->_path.'logo.gif" alt="" title="" />'.$this->l('Settings').'</legend>
				<label>'.$this->l('Maximum depth').'</label>
				<div class="margin-form">
					<input type="text" name="maxDepth" value="'.Configuration::get('BLOCK_CATEG_MAX_DEPTH').'" />
					<p class="clear">'.$this->l('Set the maximum depth of sublevels displayed in this block (0 = infinite)').'</p>
				</div>

				<label>'.$this->l('Delay').'</label>
				<div class="margin-form">
					<input type="text" name="delay" value="'.Configuration::get('BLOCK_CATEG_TOPSC_DELAY').'" />
					<p class="clear">'.$this->l('Set the delay of the animation  (0 = no animation)').'</p>
				</div>

				<center><input type="submit" name="submitBlockCategoriesTopSc" value="'.$this->l('Save').'" class="button" /></center>

			</fieldset>
		</form>';
	}

	function getTree($resultParents, $resultIds, $maxDepth, $id_category = 1, $currentDepth = 0)
	{
		global $link;

		$children = array();
		if (isset($resultParents[$id_category]) AND sizeof($resultParents[$id_category]) AND ($maxDepth == 0 OR $currentDepth < $maxDepth))
			foreach ($resultParents[$id_category] as $subcat)
				$children[] = $this->getTree($resultParents, $resultIds, $maxDepth, $subcat['id_category'], $currentDepth + 1);
		if (!isset($resultIds[$id_category]))
			return false;
		return array('id' => $id_category, 'link' => $link->getCategoryLink($id_category, $resultIds[$id_category]['link_rewrite']),
					 'name' => Category::hideCategoryPosition($resultIds[$id_category]['name']), 'desc'=> $resultIds[$id_category]['description'],
					 'children' => $children);
	}


	function hookTop($params)
	{
		global $smarty, $cookie;


		/*  ONLY FOR THEME OLDER THAN v1.0 */
		global $link;
		$smarty->assign(array(
			'categories' => Category::getHomeCategories(intval($params['cookie']->id_lang), true),
			'link' => $link
		));
		/* ELSE */

		$id_customer = intval($params['cookie']->id_customer);
		$maxdepth = Configuration::get('BLOCK_CATEG_MAX_DEPTH');

		if (!$result = Db::getInstance()->ExecuteS('
		SELECT DISTINCT c.*, cl.*
		FROM `'._DB_PREFIX_.'category` c
		LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON (c.`id_category` = cl.`id_category` AND `id_lang` = '.intval($params['cookie']->id_lang).')


		LEFT JOIN `'._DB_PREFIX_.'category_group` ctg ON (ctg.`id_category` = c.`id_category`)
		'.($id_customer ? 'INNER JOIN `'._DB_PREFIX_.'customer_group` cg ON (cg.`id_group` = ctg.`id_group` AND cg.`id_customer` = '.intval($id_customer).')' : '' ).'
		WHERE 1'
		.(intval($maxdepth) != 0 ? ' AND `level_depth` <= '.intval($maxdepth) : '').'
		AND (c.`active` = 1 OR c.`id_category`= 1)
		'.(!$id_customer ? 'AND ctg.`id_group` = 1' : '' ).'
		ORDER BY `level_depth` ASC, cl.`name` ASC'))
			return;
		$resultParents = array();
		$resultIds = array();

		foreach ($result as $row)
		{
			$$row['name'] = Category::hideCategoryPosition($row['name']);
			$resultParents[$row['id_parent']][] = $row;
			$resultIds[$row['id_category']] = $row;
		}
		$blockCategTree = $this->getTree($resultParents, $resultIds, Configuration::get('BLOCK_CATEG_MAX_DEPTH'));

		$isDhtml = (Configuration::get('BLOCK_CATEG_DHTML') == 1 ? true : false);

		if (isset($_GET['id_category']))
		{
			$cookie->last_visited_category = intval($_GET['id_category']);
			$smarty->assign('currentCategoryId', intval($_GET['id_category']));
		}
		if (isset($_GET['id_product']))
		{
			if (!isset($cookie->last_visited_category) OR !Product::idIsOnCategoryId(intval($_GET['id_product']), array('0' => array('id_category' => $cookie->last_visited_category))))
			{
				$product = new Product(intval($_GET['id_product']));
				if (isset($product) AND Validate::isLoadedObject($product))
					$cookie->last_visited_category = intval($product->id_category_default);
			}
			$smarty->assign('currentCategoryId', intval($cookie->last_visited_category));
		}
		$smarty->assign('blockCategTree', $blockCategTree);

		if (file_exists(_PS_THEME_DIR_.'modules/blockcategoriestopsc/blockcategoriestopsc.tpl'))
			$smarty->assign('branche_tpl_path', _PS_THEME_DIR_.'modules/blockcategoriestopsc/category-tree-branch.tpl');
		else
			$smarty->assign('branche_tpl_path', _PS_MODULE_DIR_.'blockcategoriestopsc/category-tree-branch.tpl');

		$smarty->assign('blockcategoriestopsc_css_href', $this->_path.'css/droppy.css');
		$smarty->assign('blockcategoriestopsc_js_href', $this->_path.'js/jquery.droppy.js');
		$smarty->assign('blockcategoriestopsc_widthtabs', Configuration::get('BLOCK_CATEG_TOPSC_WIDTH'));
		$smarty->assign('blockcategoriestopsc_delay', Configuration::get('BLOCK_CATEG_TOPSC_DELAY'));

		/* /ONLY FOR THEME OLDER THAN v1.0 */

		return $this->display(__FILE__, 'blockcategoriestopsc.tpl');
	}

	function hookRightColumn($params)
	{
		return $this->hookTop($params);
	}

    // Code � ajouter pour le support du hook "top of page"
	function hookLeftColumn($params)
	{
		return $this->hookTop($params);
	}

}

?>