<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}prestashop>homefeatured_cd2c2dc24eaf11ba856da4a2e2a248be'] = 'Produits phares';
$_MODULE['<{homefeatured}prestashop>homefeatured_b494beb5de5dd7b4fad67262e0de6321'] = 'Affiche les produits sur votre page d\'accueil';
$_MODULE['<{homefeatured}prestashop>homefeatured_ced2b9f1aad1f8a5b351a3120e4b1212'] = 'Nombre de produit invalide';
$_MODULE['<{homefeatured}prestashop>homefeatured_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{homefeatured}prestashop>homefeatured_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{homefeatured}prestashop>homefeatured_20c47700083df21a87e47d9299ef4dc4'] = 'Nombre de produits';
$_MODULE['<{homefeatured}prestashop>homefeatured_ada7594fb1614c6b6d271699c8511d5e'] = 'Le nombre de produits affichés sur la page d\'accueil (défaut : 10)';
$_MODULE['<{homefeatured}prestashop>homefeatured_0f4eda7645a471f0ccfd76b0c0e68656'] = 'Choix du tri';
$_MODULE['<{homefeatured}prestashop>homefeatured_c2ee1e1ca3418cc3720678990629d771'] = 'Pas de tri - Tri grace a Back Office => Catalogue -> Position';
$_MODULE['<{homefeatured}prestashop>homefeatured_64663f4646781c9c0110838b905daa23'] = 'Affichage Aléatoire';
$_MODULE['<{homefeatured}prestashop>homefeatured_4e4bbdbc0a0a101a7ef339fb9f06f4de'] = 'Du moins cher au plus cher';
$_MODULE['<{homefeatured}prestashop>homefeatured_288ee38bd237b6f2796f5a2cf7b715d6'] = 'Du plus cher au moins cher';
$_MODULE['<{homefeatured}prestashop>homefeatured_e5d6ba7605f8724be3a101ab348641ea'] = 'Dernier modifié en premier';
$_MODULE['<{homefeatured}prestashop>homefeatured_bd72b1345884f6b3c884e4807ba8ff02'] = 'Dernier ajouté en premier';
$_MODULE['<{homefeatured}prestashop>homefeatured_a0ee51ab33d5ba89aafaa01217622395'] = 'Alphabétique';
$_MODULE['<{homefeatured}prestashop>homefeatured_3d2e6ee477aed42a72e35343ad288118'] = 'Affichage du prix';
$_MODULE['<{homefeatured}prestashop>homefeatured_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Oui';
$_MODULE['<{homefeatured}prestashop>homefeatured_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Oui';
$_MODULE['<{homefeatured}prestashop>homefeatured_b9f5c797ebbf55adccdd8539a65a0241'] = 'Non';
$_MODULE['<{homefeatured}prestashop>homefeatured_b9f5c797ebbf55adccdd8539a65a0241'] = 'Non';
$_MODULE['<{homefeatured}prestashop>homefeatured_24a3435cb1069a5c73cce87b3a8fd227'] = 'Affichage Ajout Panier';
$_MODULE['<{homefeatured}prestashop>homefeatured_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Oui';
$_MODULE['<{homefeatured}prestashop>homefeatured_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Oui';
$_MODULE['<{homefeatured}prestashop>homefeatured_b9f5c797ebbf55adccdd8539a65a0241'] = 'Non';
$_MODULE['<{homefeatured}prestashop>homefeatured_b9f5c797ebbf55adccdd8539a65a0241'] = 'Non';
$_MODULE['<{homefeatured}prestashop>homefeatured_bca19886674fb96425fbdb03129685ab'] = 'Affichage Plus d\'Infos';
$_MODULE['<{homefeatured}prestashop>homefeatured_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Oui';
$_MODULE['<{homefeatured}prestashop>homefeatured_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Oui';
$_MODULE['<{homefeatured}prestashop>homefeatured_b9f5c797ebbf55adccdd8539a65a0241'] = 'Non';
$_MODULE['<{homefeatured}prestashop>homefeatured_b9f5c797ebbf55adccdd8539a65a0241'] = 'Non';
$_MODULE['<{homefeatured}prestashop>homefeatured_c9cc8cce247e49bae79f15173ce97354'] = 'Enregister';
$_MODULE['<{homefeatured}prestashop>homefeatured_578d26aacd7844a23f0a59ef743cf26c'] = 'PRODUIT PHARE';
$_MODULE['<{homefeatured}prestashop>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Plus d\'infos';
$_MODULE['<{homefeatured}prestashop>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Plus d\'infos';
$_MODULE['<{homefeatured}prestashop>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'Aujouter au panier';
$_MODULE['<{homefeatured}prestashop>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'Aujouter au panier';
$_MODULE['<{homefeatured}prestashop>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'Aujouter au panier';
$_MODULE['<{homefeatured}prestashop>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Aucun produit phare';

?>
