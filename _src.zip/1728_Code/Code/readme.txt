You can install Prestshop 1.3.1 from the http://www.PrestaShop.com/en/downloads.

All these files require Prestashop to run on your computer or server.
These snippets are not meant to be used separately as they are a part of the css files.

The reference to each code snippet will indicate chapter number and the code number. 
Say 1728_Ch04_05 refers to code in the 4th chapter, and the 5th code snippet in that chapter.Original files such as maintenance.css or global.css are not changed.

Thanks.
